d = {}
print("SHOP & MORE <3")
def main():
    item = input("enter Item: ")
    amount = float(input("It's Amount: "))
    d[item] = amount
    print(d)
    answer = input("Add another(0) or Exit(Any Button): ")
    again(answer)

def again(type):
    if type == '0':
        return {'0': main()
             }.get(type, "Invalid input")
    else:
        return askUser2()
        
def askUser2():
    answer = input("Enter:\n(d) = Delete\n(s) = Search\n(a) = Add Items\n(Any Button) = Exit\nChoose: ")
    if answer == 'd':
        delete(input("Enter the key you want to delete: "))
        return delete(delete)
    elif answer == 's':
        search(input("Enter the key you want to Search: "))
        return search(search)
    elif answer == 'a':
        return main()
    else:
        return bye();
def delete(key):
    try:
        del d[key]
        print("Successfully deleted\n", d)
        return again2()
    except:
        print("please,Make sure your key is correct")
        return askUser2()

def search(key):
    try:
        print(key, "is in", d[key])
        return again2()
    except:
        print("please,Make sure your key is correct")
        return askUser2()

def again2():
    answer = input("do you want to Continue? for Deleting, Searching and Adding Items? Yes(a) Exit(Any Button): ")
    if answer != 'a':
        return bye()
    else:
        return askUser2()
def bye():
    print("Your Items and Amount")
    file = open("items.txt", "w")
    file.write("The Items in your cart are : ")
    file.write(str(d))
    file.close
    print(d)
    print("Thankyou,Bye! :)")

if(__name__ == '__main__'):
    main()
