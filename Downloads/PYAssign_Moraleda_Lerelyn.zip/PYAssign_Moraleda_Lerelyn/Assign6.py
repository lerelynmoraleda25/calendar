def main():
    intNum = int(input("Please enter a number: "))
    print(binary(intNum))

def binary(n):
    l =[]
    while n != 0:
        q, r = divmod(n, 2)
        l.insert(0, r)
        n = q
    binaryList = ""
    for i in range(len(l)):
        binaryList = binaryList + str(l[i])
    return binaryList

if '__main__' == __name__:
    main()
