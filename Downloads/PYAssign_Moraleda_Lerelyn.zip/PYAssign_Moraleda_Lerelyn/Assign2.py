def main():
    grade = float(input('Please enter your percentage achieved in the class: '))
    percent = getPercentage(grade)
    if percent != -1:
        print("You got an", percent, "in the class.")
    else:
        print("Invalid")

def getPercentage(grade):    
    try :
        if grade >=93.33 and grade <=100 :
            return 'A'
        elif grade < 93.33 and grade >= 90 :
            return 'A-'
        elif grade < 90 and grade >=86.67 :
            return 'B+'
        elif grade < 86.67 and grade >=83.33 :
            return 'B'
        elif grade < 83.33 and grade >=80 :
            return 'B-'
        elif grade < 80 and grade >=76.67 :
            return 'C+'
        elif grade < 76.67 and grade >= 73.33 :
            return 'C'
        elif grade < 73.33 and grade >= 70:
            return 'C-'
        elif grade < 70 and grade >= 66.67  :
            return 'D+'
        elif grade < 66.67 and grade >= 63.33:
            return 'D'
        elif grade < 63.33 and grade >=60 :
            return 'D-'
        elif grade < 60 and grade >= 0:
            return 'F'
    except ValueError:
        return -1


main()
